package models;
public class Hotel {
    private String name;
    private String location;
    private int availableRooms;
    private double pricePerNight;

    public Hotel(String name, String location, int availableRooms, double pricePerNight) {
        this.name = name;
        this.location = location;
        this.availableRooms = availableRooms;
        this.pricePerNight = pricePerNight;
    }

    public String getName() { return name; }
    public String getLocation() { return location; }
    public int getAvailableRooms() { return availableRooms; }
    public double getPricePerNight() { return pricePerNight; }
    
    public boolean bookRoom(int numRooms) {
        if (numRooms <= availableRooms) {
            availableRooms -= numRooms;
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Hotel{" +
                "name='" + name + '\'' +
                ", location='" + location + '\'' +
                ", availableRooms=" + availableRooms +
                ", pricePerNight=" + pricePerNight +
                '}';
    }
}
