package models;
public class Booking {
    private String username;
    private String bookingType; // "Flight" or "Hotel"
    private String details;
    private double price;
    private boolean isPaid;

    public Booking(String username, String bookingType, String details, double price) {
        this.username = username;
        this.bookingType = bookingType;
        this.details = details;
        this.price = price;
        this.isPaid = false;
    }

    public String getUsername() { return username; }
    public String getBookingType() { return bookingType; }
    public String getDetails() { return details; }
    public double getPrice() { return price; }
    public boolean isPaid() { return isPaid; }
    
    public void markAsPaid() { this.isPaid = true; }
    
    @Override
    public String toString() {
        return "Booking{" +
                "username='" + username + '\'' +
                ", bookingType='" + bookingType + '\'' +
                ", details='" + details + '\'' +
                ", price=" + price +
                ", isPaid=" + isPaid +
                '}';
    }
}