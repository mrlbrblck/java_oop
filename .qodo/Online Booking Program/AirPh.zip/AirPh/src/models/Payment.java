package models;
public class Payment {
    private String username;
    private double amount;
    private String paymentMethod;
    private boolean isSuccessful;

    public Payment(String username, double amount, String paymentMethod) {
        this.username = username;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.isSuccessful = false;
    }

    public String getUsername() { return username; }
    public double getAmount() { return amount; }
    public String getPaymentMethod() { return paymentMethod; }
    public boolean isSuccessful() { return isSuccessful; }
    
    public void processPayment() {
        // Simulating payment success
        this.isSuccessful = true;
    }
    
    @Override
    public String toString() {
        return "Payment{" +
                "username='" + username + '\'' +
                ", amount=" + amount +
                ", paymentMethod='" + paymentMethod + '\'' +
                ", isSuccessful=" + isSuccessful +
                '}';
    }
}
