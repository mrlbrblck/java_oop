import java.util.*;
import models.*;
import utils.*;
// Main application class
public class App {
    private static Scanner scanner = new Scanner(System.in);
    private static List<User> users = Database.loadUsers();
    private static List<Booking> bookings = Database.loadBookings();
    private static User currentUser;

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nWelcome to AirPh Booking System");
            System.out.println("1. Sign Up\n2. Log In\n3. Exit");
            int choice = scanner.nextInt(); scanner.nextLine();
            if (choice == 1) signUp();
            else if (choice == 2) login();
            else break;
        }
    }

    private static void signUp() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        users.add(new User(username, password));
        Database.saveUsers(users);
        System.out.println("Sign up successful!");
    }

    private static void login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        for (User user : users) {
            if (user.getUsername().equals(username) && user.authenticate(password)) {
                currentUser = user;
                System.out.println("Login successful!");
                userMenu();
                return;
            }
        }
        System.out.println("Invalid credentials.");
    }

    private static void userMenu() {
        while (true) {
            System.out.println("\n1. Book Flight\n2. Book Hotel\n3. View Bookings\n4. Log Out");
            int choice = scanner.nextInt(); scanner.nextLine();
            if (choice == 1) bookFlight();
            else if (choice == 2) bookHotel();
            else if (choice == 3) viewBookings();
            else break;
        }
    }

    private static void bookFlight() {
        System.out.print("Enter date: ");
        String date = scanner.nextLine();
        System.out.print("Enter origin: ");
        String origin = scanner.nextLine();
        System.out.print("Enter destination: ");
        String destination = scanner.nextLine();
        Flight flight = new Flight("AP123", origin, destination, date, 250.0);
        Booking booking = new Booking(currentUser.getUsername(), "Flight", flight.getFlightNumber() + " from " + origin + " to " + destination, flight.getPrice());
        bookings.add(booking);
        Database.saveBookings(bookings);
        System.out.println("Flight booked!");
    }

    private static void bookHotel() {
        System.out.print("Enter location: ");
        String location = scanner.nextLine();
        Hotel hotel = new Hotel("Grand Plaza", location, 10, 100.0);
        Booking booking = new Booking(currentUser.getUsername(), "Hotel", hotel.getName() + " in " + location, hotel.getPricePerNight());
        bookings.add(booking);
        Database.saveBookings(bookings);
        System.out.println("Hotel booked!");
    }

    private static void viewBookings() {
        System.out.println("\nYour Bookings:");
        for (Booking booking : bookings) {
            if (booking.getUsername().equals(currentUser.getUsername())) {
                System.out.println(booking);
            }
        }
    }
}
